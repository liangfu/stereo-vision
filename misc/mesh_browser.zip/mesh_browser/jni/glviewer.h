/**
 * @file   glviewer.h
 * @author Liangfu Chen <chenclf@gmail.com>
 * @date   Wed Jan 18 21:17:01 2012
 * 
 * @brief  
 * 
 * 
 */

#ifndef __NDK_GL_VIEWER_H__
#define __NDK_GL_VIEWER_H__

#include "shader.h"
#include "utility.h"

typedef struct {
	GLfixed *vertexArray;
	GLubyte *colorArray;
	GLfixed *normalArray;
	GLint vertexComponents;
	GLsizei count;
} GLOBJECT;

typedef struct
{
	// Handle to a program object
	GLuint programObject;

	// Attribute locations
	GLint  positionLoc;
	GLint  normalLoc;

	// Uniform locations
	GLint  mvpLoc;

	// Vertex data
	GLfloat * vertices;
	GLfloat * normals;
	// GLushort *indices;
	GLuint *indices;
	int       numIndices;

	// Rotation angle
	GLfloat   angle;

	// MVP matrix
	ESMatrix  mvpMatrix;
	
	int mWidth;
	int mHeight;
} UserData;


static void printGLString(const char *name, GLenum s) {
    const char *v = (const char *) glGetString(s);
    LOGI("GL %s = %s\n", name, v);
}

void resizeGL(int width, int height);
void paintGL();
bool initializeGL();
bool fileOpen();
void setUserData(Mesh * mesh);
void shutdown ();

extern "C" {
    JNIEXPORT void JNICALL Java_com_android_mcamvision_GL2JNILib_resizeGL(JNIEnv * env, jobject obj,  jint width, jint height);
    JNIEXPORT void JNICALL Java_com_android_mcamvision_GL2JNILib_paintGL(JNIEnv * env, jobject obj);
    JNIEXPORT void JNICALL Java_com_android_mcamvision_GL2JNILib_initializeGL(JNIEnv * env, jobject obj);
    JNIEXPORT void JNICALL Java_com_android_mcamvision_GL2JNILib_fileOpen(JNIEnv * env, jobject obj);
    JNIEXPORT void JNICALL Java_com_android_mcamvision_GL2JNILib_shutdown(JNIEnv * env, jobject obj);
};

JNIEXPORT void JNICALL Java_com_android_mcamvision_GL2JNILib_resizeGL(JNIEnv * env, jobject obj,  jint width, jint height)
{
	resizeGL(width, height);
}

// `paintGL` function
JNIEXPORT void JNICALL Java_com_android_mcamvision_GL2JNILib_paintGL(JNIEnv * env, jobject obj)
{
    paintGL();
}

JNIEXPORT void JNICALL Java_com_android_mcamvision_GL2JNILib_initializeGL(JNIEnv * env, jobject obj)
{
    initializeGL();
}

JNIEXPORT void JNICALL Java_com_android_mcamvision_GL2JNILib_fileOpen(JNIEnv * env, jobject obj)
{
    fileOpen();
}

JNIEXPORT void JNICALL Java_com_android_mcamvision_GL2JNILib_shutdown(JNIEnv * env, jobject obj)
{
    shutdown();
}

#endif //__NDK_GL_VIEWER_H__
