/*
 * Copyright (C) 2011 Liangfu Chen <chenclf@gmail.com>
 * Copyright (C) 2009 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// OpenGL ES 2.0 code

#include <jni.h>
#include <stdio.h>
#include <string.h>

#include "common/esUtil.h"
#include "glviewer.h"

static UserData * userData = (UserData*)malloc(sizeof(UserData));

bool fileOpen()
{
	///------------------------------------------------------------
	/// all the files loaded here can be downloaded from the following site:
	///     http://people.scs.fsu.edu/~burkardt/data/obj/obj.html
	/// just download them and copy them into the right folder of your sdcard
	///------------------------------------------------------------
	
	// FILE * fp = fopen("/sdcard/mesh_browser/diamond.obj", "r");
	FILE * fp = fopen("/sdcard/mesh_browser/cube.obj", "r");
	// FILE * fp = fopen("/sdcard/mesh_browser/knee.obj", "r");
	//FILE * fp = fopen("/sdcard/mesh_browser/dodecahedron.obj", "r");
	//FILE * fp = fopen("/sdcard/mesh_browser/icosahedron.obj", "r");
	//FILE * fp = fopen("/sdcard/mesh_browser/humanoid_tri.obj", "r");
	if (!fp) {
		LOGE("__android_log_print: fail to load file.\n");
		return false;
	}else{
		LOGE("__android_log_print: file pointer is ok.\n");
	}

	Mesh * mesh = (Mesh*)malloc(sizeof(Mesh));

	mesh->v_idx = mesh->n_idx = mesh->f_idx = 0;
	mesh->v_idx_p = mesh->n_idx_p = mesh->f_idx_p = 1;

	mesh->vert = (float(*)[3])malloc(1<<(mesh->v_idx_p)*3*sizeof(float));
#if ENABLE_NORMAL
	mesh->norm = (float(*)[3])malloc(1<<(mesh->n_idx_p)*3*sizeof(float));
#endif
	mesh->face = (unsigned int(*)[3])malloc(1<<(mesh->f_idx_p)*3*sizeof(unsigned int));

	// read obj file into mesh
	readObjFile(fp, mesh);
	for (int i = 0; i < mesh->f_idx; i++){
		mesh->face[i][0]-=1;mesh->face[i][1]-=1;mesh->face[i][2]-=1;
	}

	// for (int i = 0; i < mesh->v_idx; i++)
	// 		LOGE("vert: %d %2.3f %2.3f %2.3f\n", i, mesh->vert[i][0], mesh->vert[i][1], mesh->vert[i][2]);
	// for (int i = 0; i < mesh->f_idx; i++)
	// 		LOGE("face: %d %d %d %d\n", i, mesh->face[i][0], mesh->face[i][1], mesh->face[i][2]);

	// compute normal vector by face values, as well as normalize them
	computeNormal(mesh);
	LOGE("info: %d(vert), %d(norm), %d(face)\n", mesh->v_idx, mesh->n_idx, mesh->f_idx);

	// copy mesh data to user data
	setUserData(mesh);

	// close file and release memory
	fclose(fp);
	if (mesh->vert!=NULL)
		free(mesh->vert);
	if (mesh->norm!=NULL)
		free(mesh->norm);
	if (mesh->face!=NULL)
		free(mesh->face);
	
	return true;
}

//-----------------------------------------------------------------------------
// memory allocate for user data and copy the mesh data inside
//-----------------------------------------------------------------------------
void setUserData(Mesh * mesh)
{
	float center[3]={0,};
	float largest = setExtent(mesh->vert, mesh->v_idx, center);
	LOGE("center: %f, %f, %f\n", center[0], center[1], center[2]);

	/// memory copy from data file to userData.
	userData->vertices = (float*)malloc(sizeof(float)*mesh->v_idx*3);

#if ENABLE_NORMAL
	if (mesh->n_idx==0)
		userData->normals = (float*)calloc(0, sizeof(float)*mesh->v_idx*3);
	else
		userData->normals = (float*)malloc(sizeof(float)*mesh->n_idx*3);
#endif
	userData->indices = (unsigned int*)malloc(sizeof(unsigned int)*mesh->f_idx*3);
	for (int i = 0; i < mesh->v_idx; i++){
		for (int j = 0; j < 3; j++)
			mesh->vert[i][j]=(mesh->vert[i][j]-center[j])/largest;
	}
	// for (int i = 0; i < mesh->f_idx; i++){
	// 	mesh->face[i][0]-=1;mesh->face[i][1]-=1;mesh->face[i][2]-=1;}
	memcpy(userData->vertices, mesh->vert, sizeof(float)*mesh->v_idx*3);
	LOGE("0");
#if ENABLE_NORMAL
	if (mesh->n_idx!=0 && mesh->norm!=NULL)
		memcpy(userData->normals, mesh->norm, sizeof(float)*mesh->n_idx*3);
#endif
	LOGE("0");
	memcpy(userData->indices, mesh->face, sizeof(unsigned int)*mesh->f_idx*3);
	userData->numIndices = mesh->f_idx;

	if (mesh->f_idx<16){
		for (int i = 0; i < mesh->v_idx; i++)
			LOGE("vert: %d %2.3f %2.3f %2.3f\n",
				 i, userData->vertices[i*3+0], userData->vertices[i*3+1], userData->vertices[i*3+2]);
		for (int i = 0; i < mesh->n_idx; i++)
			LOGE("norm: %d %2.3f %2.3f %2.3f\n",
				 i, userData->normals[i*3+0], userData->normals[i*3+1], userData->normals[i*3+2]);
		for (int i = 0; i < mesh->f_idx; i++)
			LOGE("face: %d %d %d %d\n",
				 i, userData->indices[i*3+0], userData->indices[i*3+1], userData->indices[i*3+2]);
	}
}

bool initializeGL()
{
	const char vShaderStr[] = MAKE_STRING(
		uniform mat4 u_mvpMatrix;
		attribute vec4 vPosition;
		attribute vec3 a_Normal;
		varying vec3 vNormal;
		void main() {
			vNormal = a_Normal;
			gl_Position = u_mvpMatrix * vPosition;
		});
	
	const char fShaderStr[] = MAKE_STRING(
		precision mediump float;
		varying vec3 vNormal;
		void main() {
			vec4 vBaseColor = vec4(0.5, 0.5, 1.0, 1.0);
			vec4 vDiffuse = vec4(0.5, 1.0, 1.0, 1.0);
			// vec3 vNormal = vec3(0.5, 0.5, 0.5);
			vec3 lightDir = vec3(0.5, -1.0, 0.5);
			float NdotL = dot(vNormal, lightDir);
			gl_FragColor = vDiffuse * NdotL * vBaseColor;
			// gl_FrontFragColor = vBaseColor;
		});

    printGLString("Version", GL_VERSION);
    printGLString("Vendor", GL_VENDOR);
    printGLString("Renderer", GL_RENDERER);
    // printGLString("Extensions", GL_EXTENSIONS);

    LOGI("setupGraphics(%d, %d)", userData->mWidth, userData->mHeight);
    userData->programObject = esLoadProgram(vShaderStr, fShaderStr);
    if (!userData->programObject) {
        LOGE("Could not create program."); exit(-1); }

    // Get the attribute locations
	userData->positionLoc = glGetAttribLocation(userData->programObject, "vPosition");
    checkGlError("glGetAttribLocation");
    LOGI("glGetAttribLocation(\"vPosition\") = %d\n", userData->positionLoc);
#if ENABLE_NORMAL
	userData->normalLoc = glGetAttribLocation(userData->programObject, "a_Normal");
    checkGlError("glGetAttribLocation");
    LOGI("glGetAttribLocation(\"aNormal\") = %d\n", userData->normalLoc);
	if (userData->normalLoc==-1) exit(-1);
#endif
	// Get the uniform locations
	userData->mvpLoc = glGetUniformLocation( userData->programObject, "u_mvpMatrix" );

	// Generate the vertex data
	// userData->numIndices = esGenCube( 1.0, &userData->vertices,
	// 								  NULL, NULL, &userData->indices );
	// userData->numIndices = esGenCube( 1.0, &userData->vertices,
	// 								  &userData->normals, NULL, (GLushort**)&userData->indices );

	// Starting rotation angle for the cube
	userData->angle = 45.0f;

	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glEnable(GL_DEPTH_TEST);
    return true;
}

void resizeGL(int w, int h)
{
	userData->mWidth = w;
	userData->mHeight = h;
}

void update(float deltaTime)
{
	ESMatrix perspective;
	ESMatrix modelview;
	float    aspect;

	// Compute a rotation angle based on time to rotate the cube
	userData->angle += ( deltaTime * 40.0f );
	if( userData->angle >= 360.0f )
		userData->angle -= 360.0f;

	// Compute the window aspect ratio
	aspect = (GLfloat) userData->mWidth / (GLfloat) userData->mHeight;

	// Generate a perspective matrix with a 60 degree FOV
	esMatrixLoadIdentity( &perspective );
	esPerspective( &perspective, 60.0f, aspect, 1.0f, 20.0f );

	// Generate a model view matrix to rotate/translate the cube
	esMatrixLoadIdentity( &modelview );

	// Translate away from the viewer
	esTranslate( &modelview, 0.0, 0.0, -2.0 );

	// Rotate the cube
	esRotate( &modelview, userData->angle, 1.0, 0.0, 1.0 );

	// Compute the final MVP by multiplying the
	// modevleiw and perspective matrices together
	esMatrixMultiply( &userData->mvpMatrix, &modelview, &perspective );
}

void paintGL() {
	update(1.0f/33.0f);
	
	glViewport(0, 0, userData->mWidth, userData->mHeight);
	
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
    checkGlError("glClearColor");
    glClear( GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT);
    checkGlError("glClear");

    glUseProgram(userData->programObject);
    checkGlError("glUseProgram");

    glVertexAttribPointer(userData->positionLoc, 3, GL_FLOAT, GL_FALSE,
						  3 * sizeof(GLfloat), userData->vertices);
#if ENABLE_NORMAL
    glVertexAttribPointer(userData->normalLoc, 3, GL_FLOAT, GL_FALSE,
						  3 * sizeof(GLfloat), userData->normals);
#endif
    checkGlError("glVertexAttribPointer");
    glEnableVertexAttribArray(userData->positionLoc);
#if ENABLE_NORMAL
    glEnableVertexAttribArray(userData->normalLoc);
#endif
    checkGlError("glEnableVertexAttribArray");

	// Load the MVP matrix
	glUniformMatrix4fv( userData->mvpLoc, 1, GL_FALSE, (GLfloat*) &userData->mvpMatrix.m[0][0] );

	glDrawElements ( GL_TRIANGLES, 3*userData->numIndices, GL_UNSIGNED_SHORT, userData->indices );
}

void shutdown()
{
	if ( userData->vertices != NULL )
		free ( userData->vertices );
	if ( userData->indices != NULL )
		free ( userData->indices );
	if ( userData->normals != NULL )
		free ( userData->normals );
	
	// Delete program object
	glDeleteProgram ( userData->programObject );
	free(userData);
}
