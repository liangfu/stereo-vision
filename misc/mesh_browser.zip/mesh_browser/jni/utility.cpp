/**
 * @file   utility.cpp
 * @author Liangfu Chen <chenclf@gmail.com>
 * @date   Thu Aug  4 16:38:54 2011
 * 
 * @brief  
 * 
 * 
 */

#include "utility.h"

//-----------------------------------------------------------------------------
// read an arbitrary wavefront obj file into mesh structure 
//-----------------------------------------------------------------------------
void readObjFile(FILE * fp, Mesh * mesh)
{
	char tmp[LINE_MAX];

	while(!feof(fp)){
		tmp[0] = ' '; // reinitialize
		fgets(tmp, LINE_MAX, fp);
		if (tmp[0]=='#'){
		}else if (tmp[0]=='g'){
			LOGE("__android_log_print: mesh group %s", tmp);
		}else if (tmp[0]=='v'&&tmp[1]!='n'){
			// get vertex data
			sscanf(tmp, "v %f %f %f\n",
				   &mesh->vert[mesh->v_idx][0],
				   &mesh->vert[mesh->v_idx][1],
				   &mesh->vert[mesh->v_idx][2]);
			mesh->v_idx++;
			if (mesh->v_idx==1<<(mesh->v_idx_p)){
				mesh->vert = (float(*)[3])
					realloc(mesh->vert, (1<<(++mesh->v_idx_p))*3*sizeof(float));
				LOGE("v_idx_p: %d\n", mesh->v_idx_p);}
#if ENABLE_NORMAL
		}else if (tmp[0]=='v'&&tmp[1]=='n'){
			// get normal data
			sscanf(tmp, "vn %f %f %f\n",
				   &mesh->norm[mesh->n_idx][0],
				   &mesh->norm[mesh->n_idx][1],
				   &mesh->norm[mesh->n_idx][2]);
			mesh->n_idx++;
			if (mesh->n_idx==1<<(mesh->n_idx_p)){
				mesh->norm = (float(*)[3])
					realloc(mesh->norm, (1<<(++mesh->n_idx_p))*3*sizeof(float));
				LOGE("n_idx_p: %d\n", mesh->n_idx_p);}
#endif
		}else if (tmp[0]=='f'){
			// get index data
			char * pch;
			int iter = 0;
			pch = strtok (tmp, " ");
			//------------------------------------------------------------
			// each face can contain more than three elements
			//------------------------------------------------------------
			while (pch != NULL){
				pch = strtok (NULL, " "); // skip first char 'f'

				if (pch==NULL) break;
				if (iter==3){
					mesh->f_idx++;
					mesh->face[mesh->f_idx][0] = mesh->face[mesh->f_idx-1][2];
					mesh->face[mesh->f_idx][1] = (unsigned int)atoi(pch);
					mesh->face[mesh->f_idx][2] = mesh->face[mesh->f_idx-1][0];
					break;
				}else if (iter>3) break;

				mesh->face[mesh->f_idx][iter++] = (unsigned int)atoi(pch);
			}

			mesh->f_idx++;
			if (mesh->f_idx==1<<(mesh->f_idx_p)){
				mesh->face = (unsigned int(*)[3])
					realloc(mesh->face, (1<<(++mesh->f_idx_p))*3*sizeof(unsigned int));
				LOGE("f_idx_p: %d\n", mesh->f_idx_p);
			}
		}
	}
}

//-----------------------------------------------------------------------------
// comute normal vector for each triangle, using by flat shading
//-----------------------------------------------------------------------------
void computeNormal(Mesh * mesh)
{
	mesh->n_idx = mesh->v_idx;
	mesh->norm = (float(*)[3])realloc(mesh->norm, mesh->n_idx*3*sizeof(float));
	for (int i = 0; i < mesh->f_idx; i++){
		int v[3];
		v[0] = mesh->face[i][0];
		v[1] = mesh->face[i][1];
		v[2] = mesh->face[i][2];
		float a[3], b[3];
		for (int j = 0; j < 3; j++){
			a[j] = mesh->vert[v[0]][j] - mesh->vert[v[1]][j];
			b[j] = mesh->vert[v[0]][j] - mesh->vert[v[2]][j];
		}
		for (int j = 0; j < 3; j++){
			// calculate cross product
			mesh->norm[v[j]][0] = a[1]*b[2]-a[2]*b[1];
			mesh->norm[v[j]][1] = a[2]*b[0]-a[0]*b[2];
			mesh->norm[v[j]][2] = a[0]*b[1]-a[1]*b[0];
		}
	}
	for (int i = 0; i < mesh->n_idx; i++){
		normalize(mesh->norm[i][0], mesh->norm[i][1], mesh->norm[i][2]);
	}
}
	
//-----------------------------------------------------------------------------
// calculate the center and the extent of the whole mesh,
// return largest dimension
//-----------------------------------------------------------------------------
float setExtent(const float (*v)[3], const int v_idx, float center[3])
{
	float max_v[3], min_v[3];
	for (int i = 0; i < 3; i++)
		min_v[i] = max_v[i] = v[0][i];
	for (int i = 0; i < v_idx; i++){
		for (int j = 0; j < 3; j++){
			min_v[j] = min(min_v[j], v[i][j]);
			max_v[j] = max(max_v[j], v[i][j]);
		}
	}
	float largest[3];
	for (int i = 0; i < 3; i++){
		center[i] = (max_v[i]+min_v[i])/2.0f;
		largest[i] = max_v[i]-min_v[i];
	}
	return max(largest[0], largest[1], largest[2]);
}

