/**
 * @file   shader.h
 * @author Liangfu Chen <chenclf@gmail.com>
 * @date   Wed Jan 18 21:16:46 2012
 * 
 * @brief  
 * 
 * 
 */

#ifndef __NDK_SHADER_H__
#define __NDK_SHADER_H__

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "utility.h"

static void checkGlError(const char* op) {
    for (GLint error = glGetError(); error; error
            = glGetError()) {
        LOGI("after %s() glError (0x%x)\n", op, error);
    }
}

GLuint createProgram(const char* pVertexSource, const char* pFragmentSource);

#endif //__NDK_SHADER_H__
