/**
 * @file   utility.h
 * @author Liangfu Chen <chenclf@gmail.com>
 * @date   Thu Aug  4 16:38:10 2011
 * 
 * @brief  
 * 
 * 
 */

#ifndef __NDK_UTILITY_H__
#define __NDK_UTILITY_H__

#include <android/log.h>

#include <GLES2/gl2.h>
#include <GLES2/gl2ext.h>

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define ENABLE_NORMAL 1

#define LINE_MAX 1024

#define MAKE_STRING(A) #A
#define abs(a) (a==0)?a:(a>0?a:-a)
#define min(a, b) a<b?a:b

template<typename T> T max(T a, T b) {return a>b?a:b;}
template<typename T> T max(T a, T b, T c) {return max(max(a, b), c);}

#define  LOG_TAG    "libmcamvision"
#define  LOGI(...)  __android_log_print(ANDROID_LOG_INFO,LOG_TAG,__VA_ARGS__)
#define  LOGE(...)  __android_log_print(ANDROID_LOG_ERROR,LOG_TAG,__VA_ARGS__)

inline void normalize(float& a, float& b, float& c)
{
	float re = sqrt(a*a+b*b+c*c);
	a/=re;	b/=re;	c/=re;
}

typedef struct _mesh{
	int v_idx, n_idx, f_idx;
	int v_idx_p, n_idx_p, f_idx_p;

	float (*vert)[3];
	float (*norm)[3];
	unsigned int (*face)[3];
} Mesh;

void readObjFile(FILE * fp, Mesh * mesh);
float setExtent(const float (*v)[3], const int v_idx, float center[3]);
void computeNormal(Mesh * mesh);

#endif //__NDK_UTILITY_H__
