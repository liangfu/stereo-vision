#include "TwoViewPointTracker.h"

namespace fvision {

TwoViewPointTracker::TwoViewPointTracker(void)
{
}

TwoViewPointTracker::~TwoViewPointTracker(void)
{
}

}