langutils
=========

:author ferryzhou@gmail.com
:version 0.1.0

Overview
--------

langutils provides some c++ language utilities such as file/directory operations.

- file
- random numbers
- string
- io
- math
- xgetopt
- iterators



Requirements
------------

- Microsoft Visual Studio 2005 or newer



