moca
====

Overview
--------

moca stands for "Model Calculation Template". Two algorithms are implemented: DLT 
and RANSAC. 
see calculators module for lots of real examples.

Examples
--------


Requirements
------------

- opencv 1.0
- Microsoft Visual Studio 2005 or newer


Tutorial
--------
