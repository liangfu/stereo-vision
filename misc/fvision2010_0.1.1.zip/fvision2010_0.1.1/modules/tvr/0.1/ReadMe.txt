Two View Reconstruction
=======================

:author: Jin Zhou (ferryzhou@gmail.com)

Overview
--------

tvr provides an implemenation for two view reconstruction. Basically, given 
a set of point correspondences, this reconstructor will output the following 
stuff:
- left and right cameras
- reconstructed 3d points


Requirements
------------

- moca 0.1
- calculators 0.1
- geom 0.1
- cvdraw 0.1
- cvutils 0.1
- opencv 1.0
- Microsoft Visual Studio 2005 or newer


