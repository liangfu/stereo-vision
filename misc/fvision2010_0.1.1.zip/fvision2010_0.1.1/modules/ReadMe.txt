fvision modules
===============

:author ferryzhou@gmail.com
:version 0.1.1

Overview
--------

fvision is an image processing and 3D vision library built upon OpenCV 1.0. 
It is composed of a set of modules. Each module is developed and maintained 
as an individual project. Dependencies between different modules are minimized. 
Currently, the modules include:

- image_filter    // image filtering
- isio            // image sequence input output
- memdb           // in memory db of points
- point_tracking  // point tracking on two views or multiple views
- cvdraw          // drawing classes and functions
- cvutils         // utils for c++
- geom            // geometric utils
- moca            // model calculation (DLT/RANSAC) and evaluation framework
- calculators     // calculators of geometric models such as homography, fundamental matrix
- tvr             // two view reconstruction
- langutils       // c++ language utils such as math, templates
- mesh            // create and export 3D mesh based on 3D points and cameras

Dependency map can be found in docs/fvision_modules.png

For usage of each module, see ReadMe.txt in each module's directory.


Requirements
------------
- opencv 1.0 (already included in the package)
- Microsoft Visual Studio 2005 or newer


Compile
-------

### Visual Studio 2005

To compile the whole package, open the solution file fvision.sln in directory 
fvision/_make/vc8. 


Usage
-----

After compilation, there is a static library file fvision.lib in fvision/lib.

Here is the project settings for using fvision:
- include directory: fvision/include
- library directory: fvision/lib
- library: fvision.lib


Release History
---------------
### 0.1.1
- added mesh module
- fixed ransac bugs
- added point tracking tools
- added homography/fundamental_matrix calculation tools

### 0.1.0
- the initial version is released