Sample: TicTacToeLib and TicTacToeMain.

These two projects work together. They demonstrate how to use the ability to
split an APK into multiple projects.

Please see the README.txt file in ../TicTacToeMain for more details.

