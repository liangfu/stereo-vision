sudo modprobe -r rtl8187
sudo modprobe uvcvideo
sudo modprobe videodev
sudo modprobe v4l2_common
sudo modprobe v4l1_compat
