sudo modprobe -r uvcvideo
sudo modprobe -r v4l2_common
sudo modprobe -r videodev
sudo modprobe -r v4l1_compat
sudo modprobe uvcvideo
sudo modprobe videodev
sudo modprobe v4l2_common
sudo modprobe v4l1_compat
